from fastapi import FastAPI, APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional, Dict
import uuid
from datetime import datetime, timezone
from groq import Groq
import json
import httpx
import base64
from emergentintegrations.payments.stripe.checkout import StripeCheckout, CheckoutSessionResponse, CheckoutStatusResponse, CheckoutSessionRequest

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Groq client
groq_client = Groq(api_key=os.environ.get('GROQ_API_KEY', ''))

# Create the main app
app = FastAPI(title="Nyxen AI Backend", version="1.0.0")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# === CREDIT SYSTEM CONSTANTS ===
FREE_CREDITS = 25
ADMIN_EMAILS = ["smcantrellbooks@gmail.com"]  # Admin users get unlimited credits
CREDIT_COSTS = {
    "chat": 1,
    "image": 5,
    "story": 3,
    "illustration": 5,
    "rewrite": 1,
    "format": 1
}

# Credit packages (amount in USD)
CREDIT_PACKAGES = {
    "starter": {"credits": 100, "price": 5.00, "name": "Starter Pack"},
    "popular": {"credits": 300, "price": 10.00, "name": "Popular Pack"},
    "pro": {"credits": 750, "price": 20.00, "name": "Pro Pack"}
}

# === MODELS ===

class ChatMessage(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: List[ChatMessage]
    conversation_id: Optional[str] = None
    temperature: float = 0.7
    max_tokens: int = 1024

class ChatResponse(BaseModel):
    id: str
    conversation_id: str
    content: str
    created_at: str

class Conversation(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str = "New Conversation"
    messages: List[dict] = []
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

class Story(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    content: str
    genre: str = "General"
    word_count: int = 0
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

class StoryCreate(BaseModel):
    title: str
    content: str
    genre: str = "General"

class StoryUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    genre: Optional[str] = None

class Document(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    content: str
    doc_type: str = "article"
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

class DocumentCreate(BaseModel):
    title: str
    content: str
    doc_type: str = "article"

class RewriteRequest(BaseModel):
    text: str
    style: str = "professional"  # professional, casual, formal, creative

class FormatRequest(BaseModel):
    text: str
    format_type: str = "paragraphs"  # paragraphs, bullets, numbered, headers

class ImageGenerationRequest(BaseModel):
    prompt: str
    style: str = "realistic"  # realistic, artistic, fantasy, anime
    user_id: Optional[str] = None

# Credit System Models
class UserCredits(BaseModel):
    user_id: str
    credits: int = FREE_CREDITS
    total_purchased: int = 0
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

class CreditTransaction(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    amount: int  # positive for add, negative for use
    action: str  # "chat", "image", "purchase", etc.
    balance_after: int
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

class PaymentTransaction(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    session_id: str
    package_id: str
    amount: float
    currency: str = "usd"
    credits: int
    status: str = "pending"  # pending, paid, failed, expired
    payment_status: str = "initiated"
    metadata: Dict[str, str] = {}
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

class PurchaseCreditsRequest(BaseModel):
    package_id: str
    origin_url: str

class GeneratedImage(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    prompt: str
    image_url: str
    style: str = "realistic"
    story_id: Optional[str] = None
    chapter_title: Optional[str] = None
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

class StoryIllustrationRequest(BaseModel):
    story_id: str
    chapter_content: str
    chapter_title: str = "Chapter"
    style: str = "fantasy"

# === NYXEN SYSTEM PROMPT ===
NYXEN_SYSTEM_PROMPT = """You are Nyxen, a professional, smart, and friendly AI assistant specializing in creative writing, storytelling, and content creation. 

Your personality traits:
- Professional yet warm and approachable
- Encouraging and supportive of creative endeavors
- Knowledgeable about writing techniques, story structure, and content creation
- Clear and articulate in your responses
- You help with story creation, editing, rewriting, formatting, and publishing

When helping with creative writing:
- Offer constructive feedback
- Suggest improvements while respecting the author's voice
- Help with plot development, character creation, and world-building
- Assist with editing, proofreading, and formatting

Always maintain a helpful, professional demeanor while being personable and encouraging."""

# === CREDIT HELPER FUNCTIONS ===

async def get_or_create_user(user_id: str) -> dict:
    """Get or create a user's credit balance"""
    user = await db.user_credits.find_one({"user_id": user_id}, {"_id": 0})
    if not user:
        # Check if this is an admin user - give them unlimited credits
        initial_credits = 999999 if user_id.startswith("admin_") else FREE_CREDITS
        user = UserCredits(user_id=user_id, credits=initial_credits).model_dump()
        await db.user_credits.insert_one(user)
    return user

async def check_credits(user_id: str, action: str) -> tuple[bool, int, int]:
    """Check if user has enough credits. Returns (has_enough, current_balance, cost)"""
    user = await get_or_create_user(user_id)
    cost = CREDIT_COSTS.get(action, 1)
    return user["credits"] >= cost, user["credits"], cost

async def use_credits(user_id: str, action: str) -> dict:
    """Deduct credits for an action. Returns updated balance."""
    cost = CREDIT_COSTS.get(action, 1)
    
    result = await db.user_credits.find_one_and_update(
        {"user_id": user_id, "credits": {"$gte": cost}},
        {
            "$inc": {"credits": -cost},
            "$set": {"updated_at": datetime.now(timezone.utc).isoformat()}
        },
        return_document=True
    )
    
    if not result:
        raise HTTPException(status_code=402, detail="Insufficient credits")
    
    # Log transaction
    transaction = CreditTransaction(
        user_id=user_id,
        amount=-cost,
        action=action,
        balance_after=result["credits"]
    )
    await db.credit_transactions.insert_one(transaction.model_dump())
    
    return {"credits": result["credits"], "cost": cost}

async def add_credits(user_id: str, amount: int, reason: str = "purchase") -> dict:
    """Add credits to user account"""
    result = await db.user_credits.find_one_and_update(
        {"user_id": user_id},
        {
            "$inc": {"credits": amount, "total_purchased": amount},
            "$set": {"updated_at": datetime.now(timezone.utc).isoformat()}
        },
        return_document=True,
        upsert=True
    )
    
    # Log transaction
    transaction = CreditTransaction(
        user_id=user_id,
        amount=amount,
        action=reason,
        balance_after=result["credits"]
    )
    await db.credit_transactions.insert_one(transaction.model_dump())
    
    return {"credits": result["credits"]}

# === ROUTES ===

@api_router.get("/")
async def root():
    return {"message": "Nyxen AI Backend is running"}

@api_router.get("/health")
async def health():
    return {"status": "healthy", "service": "nyxen-api"}

# Chat endpoints
@api_router.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    try:
        # Prepare messages with system prompt
        messages = [{"role": "system", "content": NYXEN_SYSTEM_PROMPT}]
        messages.extend([{"role": m.role, "content": m.content} for m in request.messages])
        
        # Call Groq API
        response = groq_client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=messages,
            temperature=request.temperature,
            max_completion_tokens=request.max_tokens,
        )
        
        assistant_content = response.choices[0].message.content
        
        # Create or update conversation
        conversation_id = request.conversation_id or str(uuid.uuid4())
        
        # Store in database
        conversation_doc = {
            "id": conversation_id,
            "messages": [{"role": m.role, "content": m.content} for m in request.messages] + 
                       [{"role": "assistant", "content": assistant_content}],
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        
        await db.conversations.update_one(
            {"id": conversation_id},
            {"$set": conversation_doc},
            upsert=True
        )
        
        return ChatResponse(
            id=response.id,
            conversation_id=conversation_id,
            content=assistant_content,
            created_at=datetime.now(timezone.utc).isoformat()
        )
        
    except Exception as e:
        logger.error(f"Chat error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/chat/stream")
async def chat_stream(request: ChatRequest):
    try:
        messages = [{"role": "system", "content": NYXEN_SYSTEM_PROMPT}]
        messages.extend([{"role": m.role, "content": m.content} for m in request.messages])
        
        def generate():
            stream = groq_client.chat.completions.create(
                model="llama-3.1-8b-instant",
                messages=messages,
                temperature=request.temperature,
                max_completion_tokens=request.max_tokens,
                stream=True
            )
            
            for chunk in stream:
                if chunk.choices[0].delta.content:
                    data = {"content": chunk.choices[0].delta.content, "done": False}
                    yield f"data: {json.dumps(data)}\n\n"
                
                if chunk.choices[0].finish_reason:
                    data = {"content": "", "done": True, "finish_reason": chunk.choices[0].finish_reason}
                    yield f"data: {json.dumps(data)}\n\n"
        
        return StreamingResponse(
            generate(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "Connection": "keep-alive"}
        )
        
    except Exception as e:
        logger.error(f"Stream error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Conversation endpoints
@api_router.get("/conversations", response_model=List[dict])
async def get_conversations():
    conversations = await db.conversations.find({}, {"_id": 0}).sort("updated_at", -1).to_list(50)
    return conversations

@api_router.get("/conversations/{conversation_id}")
async def get_conversation(conversation_id: str):
    conversation = await db.conversations.find_one({"id": conversation_id}, {"_id": 0})
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return conversation

@api_router.delete("/conversations/{conversation_id}")
async def delete_conversation(conversation_id: str):
    result = await db.conversations.delete_one({"id": conversation_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return {"message": "Conversation deleted"}

# Story endpoints
@api_router.post("/stories", response_model=Story)
async def create_story(story: StoryCreate):
    story_doc = Story(
        title=story.title,
        content=story.content,
        genre=story.genre,
        word_count=len(story.content.split())
    )
    await db.stories.insert_one(story_doc.model_dump())
    return story_doc

@api_router.get("/stories", response_model=List[Story])
async def get_stories():
    stories = await db.stories.find({}, {"_id": 0}).sort("updated_at", -1).to_list(100)
    return [Story(**s) for s in stories]

@api_router.get("/stories/{story_id}", response_model=Story)
async def get_story(story_id: str):
    story = await db.stories.find_one({"id": story_id}, {"_id": 0})
    if not story:
        raise HTTPException(status_code=404, detail="Story not found")
    return Story(**story)

@api_router.put("/stories/{story_id}", response_model=Story)
async def update_story(story_id: str, update: StoryUpdate):
    updates = {k: v for k, v in update.model_dump().items() if v is not None}
    if "content" in updates:
        updates["word_count"] = len(updates["content"].split())
    updates["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    result = await db.stories.update_one({"id": story_id}, {"$set": updates})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Story not found")
    
    story = await db.stories.find_one({"id": story_id}, {"_id": 0})
    return Story(**story)

@api_router.delete("/stories/{story_id}")
async def delete_story(story_id: str):
    result = await db.stories.delete_one({"id": story_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Story not found")
    return {"message": "Story deleted"}

# Document endpoints
@api_router.post("/documents", response_model=Document)
async def create_document(doc: DocumentCreate):
    doc_obj = Document(title=doc.title, content=doc.content, doc_type=doc.doc_type)
    await db.documents.insert_one(doc_obj.model_dump())
    return doc_obj

@api_router.get("/documents", response_model=List[Document])
async def get_documents():
    docs = await db.documents.find({}, {"_id": 0}).sort("updated_at", -1).to_list(100)
    return [Document(**d) for d in docs]

@api_router.get("/documents/{doc_id}", response_model=Document)
async def get_document(doc_id: str):
    doc = await db.documents.find_one({"id": doc_id}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    return Document(**doc)

@api_router.put("/documents/{doc_id}", response_model=Document)
async def update_document(doc_id: str, content: str, title: Optional[str] = None):
    updates = {"content": content, "updated_at": datetime.now(timezone.utc).isoformat()}
    if title:
        updates["title"] = title
    
    result = await db.documents.update_one({"id": doc_id}, {"$set": updates})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Document not found")
    
    doc = await db.documents.find_one({"id": doc_id}, {"_id": 0})
    return Document(**doc)

@api_router.delete("/documents/{doc_id}")
async def delete_document(doc_id: str):
    result = await db.documents.delete_one({"id": doc_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Document not found")
    return {"message": "Document deleted"}

# AI Writing Tools
@api_router.post("/ai/rewrite")
async def rewrite_text(request: RewriteRequest):
    try:
        style_prompts = {
            "professional": "Rewrite this text in a professional, business-appropriate tone while maintaining the original meaning:",
            "casual": "Rewrite this text in a casual, conversational tone while maintaining the original meaning:",
            "formal": "Rewrite this text in a formal, academic tone while maintaining the original meaning:",
            "creative": "Rewrite this text in a more creative, engaging way while maintaining the original meaning:"
        }
        
        prompt = style_prompts.get(request.style, style_prompts["professional"])
        
        response = groq_client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {"role": "system", "content": "You are a professional editor. Provide only the rewritten text without any explanations or prefixes."},
                {"role": "user", "content": f"{prompt}\n\n{request.text}"}
            ],
            temperature=0.7,
            max_completion_tokens=2048,
        )
        
        return {"rewritten": response.choices[0].message.content}
        
    except Exception as e:
        logger.error(f"Rewrite error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/ai/format")
async def format_text(request: FormatRequest):
    try:
        format_prompts = {
            "paragraphs": "Format this text into well-structured paragraphs:",
            "bullets": "Convert this text into a bulleted list:",
            "numbered": "Convert this text into a numbered list:",
            "headers": "Organize this text with appropriate headers and sections:"
        }
        
        prompt = format_prompts.get(request.format_type, format_prompts["paragraphs"])
        
        response = groq_client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {"role": "system", "content": "You are a professional formatter. Provide only the formatted text without any explanations."},
                {"role": "user", "content": f"{prompt}\n\n{request.text}"}
            ],
            temperature=0.3,
            max_completion_tokens=2048,
        )
        
        return {"formatted": response.choices[0].message.content}
        
    except Exception as e:
        logger.error(f"Format error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/ai/generate-story")
async def generate_story(prompt: str, genre: str = "fantasy", length: str = "short"):
    try:
        length_tokens = {"short": 500, "medium": 1000, "long": 2000}
        max_tokens = length_tokens.get(length, 500)
        
        response = groq_client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {"role": "system", "content": f"You are a creative storyteller specializing in {genre} stories. Write engaging, well-structured narratives."},
                {"role": "user", "content": f"Write a {length} {genre} story based on this prompt: {prompt}"}
            ],
            temperature=0.8,
            max_completion_tokens=max_tokens,
        )
        
        return {"story": response.choices[0].message.content}
        
    except Exception as e:
        logger.error(f"Story generation error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/ai/continue-story")
async def continue_story(story_so_far: str, direction: str = ""):
    try:
        prompt = f"Continue this story naturally"
        if direction:
            prompt += f" in this direction: {direction}"
        
        response = groq_client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {"role": "system", "content": "You are a creative storyteller. Continue the story seamlessly, matching the existing style and tone."},
                {"role": "user", "content": f"{prompt}:\n\n{story_so_far}"}
            ],
            temperature=0.8,
            max_completion_tokens=1024,
        )
        
        return {"continuation": response.choices[0].message.content}
        
    except Exception as e:
        logger.error(f"Continue story error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/ai/edit-suggestions")
async def get_edit_suggestions(text: str):
    try:
        response = groq_client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {"role": "system", "content": "You are a professional editor. Provide specific, actionable editing suggestions."},
                {"role": "user", "content": f"Analyze this text and provide editing suggestions for improving clarity, grammar, style, and engagement:\n\n{text}"}
            ],
            temperature=0.5,
            max_completion_tokens=1024,
        )
        
        return {"suggestions": response.choices[0].message.content}
        
    except Exception as e:
        logger.error(f"Edit suggestions error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Image Generation endpoint using APIFree.ai with Seedream 4.5
@api_router.post("/ai/generate-image")
async def generate_image(request: ImageGenerationRequest):
    try:
        api_key = os.environ.get('APIFREE_API_KEY', '')
        
        if not api_key:
            raise HTTPException(status_code=503, detail="Image generation service not configured. Please set APIFREE_API_KEY.")
        
        # Enhance prompt based on style
        style_enhancers = {
            "realistic": "highly detailed, photorealistic, 8k resolution, professional photography, cinematic lighting",
            "artistic": "artistic style, oil painting, vibrant colors, masterpiece, fine art, brush strokes",
            "fantasy": "fantasy art style, magical, ethereal lighting, epic scene, concept art, dreamlike",
            "anime": "anime style, detailed illustration, studio ghibli inspired, vibrant colors, cel shading"
        }
        
        enhanced_prompt = f"{request.prompt}, {style_enhancers.get(request.style, style_enhancers['realistic'])}"
        
        # Call APIFree.ai Seedream 4.5 API
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                "https://api.apifree.ai/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "bytedance/seedream-4.5",
                    "prompt": enhanced_prompt
                }
            )
            
            if response.status_code != 200:
                error_detail = response.text
                logger.error(f"APIFree error: {error_detail}")
                raise HTTPException(status_code=response.status_code, detail=f"Image generation failed: {error_detail}")
            
            result = response.json()
            logger.info(f"APIFree response code: {result.get('code')}")
            
            # Extract image URL from APIFree response format
            image_url = None
            if result.get("code") == 200 and "resp_data" in result:
                resp_data = result["resp_data"]
                if "data" in resp_data and len(resp_data["data"]) > 0:
                    image_url = resp_data["data"][0].get("url")
            
            if image_url:
                # Store in database
                image_doc = GeneratedImage(
                    prompt=request.prompt,
                    image_url=str(image_url),
                    style=request.style
                )
                await db.generated_images.insert_one(image_doc.model_dump())
                
                return {
                    "id": image_doc.id,
                    "image_url": str(image_url),
                    "prompt": request.prompt,
                    "style": request.style
                }
            else:
                error_msg = result.get("error", {}).get("message", "Unknown error")
                logger.error(f"APIFree response: {result}")
                raise HTTPException(status_code=500, detail=f"Image generation failed: {error_msg}")
        
    except httpx.TimeoutException:
        logger.error("Image generation timeout")
        raise HTTPException(status_code=504, detail="Image generation timed out. Please try again.")
    except Exception as e:
        logger.error(f"Image generation error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/ai/images", response_model=List[dict])
async def get_generated_images():
    """Get all generated images"""
    images = await db.generated_images.find({}, {"_id": 0}).sort("created_at", -1).to_list(50)
    return images

@api_router.get("/ai/images/story/{story_id}", response_model=List[dict])
async def get_story_illustrations(story_id: str):
    """Get illustrations for a specific story"""
    images = await db.generated_images.find({"story_id": story_id}, {"_id": 0}).sort("created_at", -1).to_list(50)
    return images

@api_router.post("/ai/generate-illustration")
async def generate_story_illustration(request: StoryIllustrationRequest):
    """Generate an illustration based on story chapter content"""
    try:
        api_key = os.environ.get('APIFREE_API_KEY', '')
        
        if not api_key:
            raise HTTPException(status_code=503, detail="Image generation service not configured.")
        
        # Use Groq to analyze the chapter and create an image prompt
        chapter_summary = request.chapter_content[:2000]  # Limit content for prompt generation
        
        prompt_response = groq_client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {"role": "system", "content": """You are an expert at creating vivid image prompts for AI image generation. 
                Given a story chapter, extract the most visually striking scene and create a detailed image prompt.
                Focus on: main characters' appearance, setting, atmosphere, lighting, and key action.
                Output ONLY the image prompt, no explanations. Keep it under 200 words."""},
                {"role": "user", "content": f"Create an image prompt for this chapter titled '{request.chapter_title}':\n\n{chapter_summary}"}
            ],
            temperature=0.7,
            max_completion_tokens=300,
        )
        
        generated_prompt = prompt_response.choices[0].message.content.strip()
        
        # Style enhancers for story illustrations
        style_enhancers = {
            "realistic": "cinematic lighting, photorealistic, detailed, dramatic scene",
            "artistic": "oil painting style, artistic, vibrant colors, masterpiece illustration",
            "fantasy": "fantasy art, magical atmosphere, ethereal lighting, epic scene, concept art",
            "anime": "anime style, detailed illustration, dynamic composition, vibrant"
        }
        
        enhanced_prompt = f"{generated_prompt}, {style_enhancers.get(request.style, style_enhancers['fantasy'])}, book illustration"
        
        # Generate the image
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                "https://api.apifree.ai/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "bytedance/seedream-4.5",
                    "prompt": enhanced_prompt
                }
            )
            
            if response.status_code != 200:
                raise HTTPException(status_code=response.status_code, detail="Image generation failed")
            
            result = response.json()
            
            image_url = None
            if result.get("code") == 200 and "resp_data" in result:
                resp_data = result["resp_data"]
                if "data" in resp_data and len(resp_data["data"]) > 0:
                    image_url = resp_data["data"][0].get("url")
            
            if image_url:
                # Store with story reference
                image_doc = GeneratedImage(
                    prompt=generated_prompt,
                    image_url=str(image_url),
                    style=request.style,
                    story_id=request.story_id,
                    chapter_title=request.chapter_title
                )
                await db.generated_images.insert_one(image_doc.model_dump())
                
                return {
                    "id": image_doc.id,
                    "image_url": str(image_url),
                    "prompt": generated_prompt,
                    "chapter_title": request.chapter_title,
                    "style": request.style
                }
            else:
                raise HTTPException(status_code=500, detail="Image generation failed")
        
    except Exception as e:
        logger.error(f"Story illustration error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# === CREDIT & PAYMENT ENDPOINTS ===

@api_router.get("/credits/{user_id}")
async def get_credits(user_id: str):
    """Get user's credit balance"""
    user = await get_or_create_user(user_id)
    return {
        "user_id": user_id,
        "credits": user["credits"],
        "total_purchased": user.get("total_purchased", 0),
        "costs": CREDIT_COSTS
    }

@api_router.get("/credits/packages/list")
async def get_credit_packages():
    """Get available credit packages"""
    return {
        "packages": [
            {"id": k, **v} for k, v in CREDIT_PACKAGES.items()
        ],
        "costs": CREDIT_COSTS
    }

@api_router.post("/credits/purchase")
async def purchase_credits(request: PurchaseCreditsRequest, http_request: Request):
    """Create a Stripe checkout session to purchase credits"""
    try:
        if request.package_id not in CREDIT_PACKAGES:
            raise HTTPException(status_code=400, detail="Invalid package")
        
        package = CREDIT_PACKAGES[request.package_id]
        user_id = request.origin_url.split("?user_id=")[-1] if "?user_id=" in request.origin_url else str(uuid.uuid4())
        
        # Initialize Stripe
        api_key = os.environ.get('STRIPE_API_KEY', '')
        if not api_key:
            raise HTTPException(status_code=503, detail="Payment service not configured")
        
        host_url = str(http_request.base_url).rstrip('/')
        webhook_url = f"{host_url}/api/webhook/stripe"
        stripe_checkout = StripeCheckout(api_key=api_key, webhook_url=webhook_url)
        
        # Build URLs
        success_url = f"{request.origin_url}?session_id={{CHECKOUT_SESSION_ID}}&status=success"
        cancel_url = f"{request.origin_url}?status=cancelled"
        
        # Create checkout session
        checkout_request = CheckoutSessionRequest(
            amount=package["price"],
            currency="usd",
            success_url=success_url,
            cancel_url=cancel_url,
            metadata={
                "user_id": user_id,
                "package_id": request.package_id,
                "credits": str(package["credits"])
            }
        )
        
        session = await stripe_checkout.create_checkout_session(checkout_request)
        
        # Store payment transaction
        payment_tx = PaymentTransaction(
            user_id=user_id,
            session_id=session.session_id,
            package_id=request.package_id,
            amount=package["price"],
            credits=package["credits"],
            status="pending",
            payment_status="initiated",
            metadata={"package_name": package["name"]}
        )
        await db.payment_transactions.insert_one(payment_tx.model_dump())
        
        return {
            "checkout_url": session.url,
            "session_id": session.session_id
        }
        
    except Exception as e:
        logger.error(f"Purchase error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/credits/checkout/status/{session_id}")
async def check_payment_status(session_id: str, http_request: Request):
    """Check the status of a payment and add credits if successful"""
    try:
        # Get payment transaction
        payment_tx = await db.payment_transactions.find_one({"session_id": session_id}, {"_id": 0})
        if not payment_tx:
            raise HTTPException(status_code=404, detail="Payment session not found")
        
        # If already processed, return current status
        if payment_tx["payment_status"] == "paid":
            user = await get_or_create_user(payment_tx["user_id"])
            return {
                "status": "complete",
                "payment_status": "paid",
                "credits_added": payment_tx["credits"],
                "current_balance": user["credits"]
            }
        
        # Check with Stripe
        api_key = os.environ.get('STRIPE_API_KEY', '')
        host_url = str(http_request.base_url).rstrip('/')
        webhook_url = f"{host_url}/api/webhook/stripe"
        stripe_checkout = StripeCheckout(api_key=api_key, webhook_url=webhook_url)
        
        status = await stripe_checkout.get_checkout_status(session_id)
        
        if status.payment_status == "paid" and payment_tx["payment_status"] != "paid":
            # Add credits (only once)
            await add_credits(payment_tx["user_id"], payment_tx["credits"], f"purchase_{payment_tx['package_id']}")
            
            # Update payment transaction
            await db.payment_transactions.update_one(
                {"session_id": session_id},
                {"$set": {
                    "status": "complete",
                    "payment_status": "paid",
                    "updated_at": datetime.now(timezone.utc).isoformat()
                }}
            )
            
            user = await get_or_create_user(payment_tx["user_id"])
            return {
                "status": "complete",
                "payment_status": "paid",
                "credits_added": payment_tx["credits"],
                "current_balance": user["credits"]
            }
        
        elif status.status == "expired":
            await db.payment_transactions.update_one(
                {"session_id": session_id},
                {"$set": {"status": "expired", "payment_status": "expired"}}
            )
            return {"status": "expired", "payment_status": "expired"}
        
        return {
            "status": status.status,
            "payment_status": status.payment_status
        }
        
    except Exception as e:
        logger.error(f"Payment status check error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/webhook/stripe")
async def stripe_webhook(request: Request):
    """Handle Stripe webhooks"""
    try:
        body = await request.body()
        signature = request.headers.get("Stripe-Signature")
        
        api_key = os.environ.get('STRIPE_API_KEY', '')
        host_url = str(request.base_url).rstrip('/')
        webhook_url = f"{host_url}/api/webhook/stripe"
        stripe_checkout = StripeCheckout(api_key=api_key, webhook_url=webhook_url)
        
        webhook_response = await stripe_checkout.handle_webhook(body, signature)
        
        if webhook_response.payment_status == "paid":
            session_id = webhook_response.session_id
            payment_tx = await db.payment_transactions.find_one({"session_id": session_id})
            
            if payment_tx and payment_tx["payment_status"] != "paid":
                await add_credits(payment_tx["user_id"], payment_tx["credits"], f"purchase_{payment_tx['package_id']}")
                await db.payment_transactions.update_one(
                    {"session_id": session_id},
                    {"$set": {"status": "complete", "payment_status": "paid"}}
                )
        
        return {"received": True}
        
    except Exception as e:
        logger.error(f"Webhook error: {str(e)}")
        return {"received": True, "error": str(e)}

@api_router.get("/credits/history/{user_id}")
async def get_credit_history(user_id: str):
    """Get user's credit transaction history"""
    transactions = await db.credit_transactions.find(
        {"user_id": user_id}, {"_id": 0}
    ).sort("created_at", -1).to_list(50)
    return {"transactions": transactions}

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
