# Nyxen AI Chatbot - Product Requirements Document

## Original Problem Statement
Build an AI chatbot named Nyxen for website that is capable of TTS text to speech, audio generation, story creation, and full publishing capabilities including writing, editing, formatting, and rewriting. Also capable of text to images. Make her a fully capable AI bot compared to ChatGPT and Co-pilot.

## User Personas
- **Writers**: Need AI assistance for creative writing, story generation, and editing
- **Content Creators**: Need help with document creation, formatting, and rewriting
- **Visual Artists**: Need AI image generation from text prompts
- **General Users**: Seeking conversational AI assistance with voice capabilities

## Core Requirements (Static)
1. AI Chat Interface with avatar
2. Text-to-Speech functionality
3. Story creation and generation
4. Document publishing tools (write, edit, format, rewrite)
5. Text-to-Image generation
6. Story Illustrations
7. Professional, smart, friendly personality

## Architecture
- **Frontend**: React with Tailwind CSS, shadcn UI components
- **Backend**: FastAPI with MongoDB
- **AI Chat**: Groq with Llama 3.1 8B
- **AI Images**: APIFree.ai with ByteDance Seedream 4.5
- **TTS**: Browser Web Speech API
- **Design**: "Organic & Earthy" theme with cream/charcoal palette, Playfair Display font

## What's Been Implemented (Jan 2026)
- [x] Chat page with Nyxen avatar and welcome message
- [x] AI-powered chat using Groq/Llama 3.1 8B
- [x] Text-to-Speech with browser Web Speech API
- [x] Story Studio with AI story generation
- [x] Document Editor with AI rewrite/format tools
- [x] Image Generator with Seedream 4.5 (via APIFree.ai)
- [x] Image Gallery with download functionality
- [x] **Story Illustrations Feature** - Auto-generate images from story content
- [x] Settings page with voice configuration
- [x] Navigation between all pages (Chat, Story Studio, Editor, Images, Settings)
- [x] MongoDB storage for conversations, stories, documents, images

## API Endpoints
- POST /api/chat - Chat with Nyxen
- POST /api/chat/stream - Streaming chat responses
- CRUD /api/stories - Story management
- CRUD /api/documents - Document management
- POST /api/ai/rewrite - Rewrite text in different styles
- POST /api/ai/format - Format text
- POST /api/ai/generate-story - AI story generation
- POST /api/ai/continue-story - Continue an existing story
- POST /api/ai/edit-suggestions - Get editing suggestions
- POST /api/ai/generate-image - Generate images with Seedream 4.5
- GET /api/ai/images - Get generated images gallery
- **POST /api/ai/generate-illustration** - Generate story illustrations
- **GET /api/ai/images/story/{story_id}** - Get illustrations for a story

## External Services
- Groq API (Llama 3.1 8B) - Chat generation
- APIFree.ai (Seedream 4.5) - Image generation

## Prioritized Backlog

### P0 - Done
- Core chat functionality
- Story generation
- Document editing
- Image generation (Seedream 4.5)
- Story Illustrations

### P1 - Next
- Import user stories (like JALEN_DRAFT .docx)
- User authentication for saving preferences
- Kokoro TTS integration

### P2 - Future
- Multiple conversation threads
- Export to PDF/DOCX
- Collaborative editing
- Custom AI personas
- Video generation

## Next Tasks
1. Add story import feature for .docx files
2. Integrate user authentication
3. Add image-to-image editing capabilities
